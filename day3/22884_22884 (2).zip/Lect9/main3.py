class ____:
    def __init__(self):
        self._ = "_"
        self.__ = "____"
        self.___ = "____"
        self.____ = "_____"

    
def main():
    """
    What?
    """
    o = ____()
    print(type(o))
    print(dir(o))
    print(o.__)


if __name__ == "__main__":
    main()