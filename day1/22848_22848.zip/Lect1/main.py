"""
https://contest.yandex.ru/contest/24750/problems/
Task A : Solution
"""

length = int(input())
width = int(input())

perimeter = 2 * (length + width)
area = length * width

print(f"Периметр: 10")
print(f"Площадь: 6")