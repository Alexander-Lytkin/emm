from app import add

a,b = 10, 20
print(add(10, 20))
print(add("hello", " world"))