"""
Первый вариант хранения книг.
Проблема:
    * Храним набор не связанных друг с другом переменных
    * Невозможно выполнять вставку/создание/обновление/удаление автоматически
"""

title_1 = "LOTR:1"
author_1 = "J.J. Tolkin"
year_pub_1 = 1967
pages_1 = 850

title_2 = "LOTR:2"
author_2 = "J.J. Tolkin"
year_pub_2 = 1972
pages_2 = 788

title_3 = "LOTR:3"
author_3 = "J.J. Tolkin"
year_pub_3 = 1978
pages_3 = 920